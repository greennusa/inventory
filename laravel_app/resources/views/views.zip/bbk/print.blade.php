
<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{$r->nomor."-".$r->tanggal}}</title>

    <!-- Styles -->
    
    <link rel="stylesheet" type="text/css" href="{{ asset('bootstrap/theme/16/bootstrap.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('selectbox/css/bootstrap-select.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('jquery-ui/jquery-ui.min.css') }}">




    <script src="{{ asset('jquery/jquery-1.11.3.min.js') }}"></script>
    <script src="{{ asset('bootstrap/js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('selectbox/js/bootstrap-select.min.js') }}"></script>
    <script src="{{ asset('jquery-ui/jquery-ui.min.js') }}"></script>
    <script src="{{ asset('js/bootstrap-notify.min.js') }}" ></script>

    
    <style>
        .ui-datepicker-calendar {
            display: none;
        }
    </style>
    <style type="text/css">

        #gambar{

            float: right; margin-top: -40%; margin-right: auto;

            max-width: 40%;

            max-height: 30%;

        }

        @media screen and (max-width: 1199px) {

          #gambar {

            float: none;

            margin-top: 5px;

            margin-bottom: 5px;

          }

        }



    </style>



</head>
<body >
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default"  style="border: none;">
               

                <div class="panel-body" style="border: none;">
                    <table style="float: right;" width="100%" >
						<tr>
							<td rowspan="4" colspan="2" width="100"><img width="100" src="<?php echo "http://$_SERVER[HTTP_HOST]"; ?>/inventoryudit/assets/images/udit.png" alt="" /></td>
							<td colspan="6"><h2>PT. Utama Damai Indah Timber</h2></td>
							<td>&nbsp;</td>
							<td width="20%">&nbsp;</td>
							<td width="1%">&nbsp;</td>
							<td width="1%">&nbsp;</td>
							<td>Nomor : </td>
							<td colspan="4"><?php echo @$r->nomor ?> </td>
						</tr>
                        <tr>
                            <td colspan="6">&nbsp;</td>
                            <td>&nbsp;</td>
                            <td>&nbsp;</td>
                            <td>&nbsp;</td>
                            <td>&nbsp;</td>
                            <td>Halaman : </td>
                            <td colspan="4"><?php echo @$r->halaman ?> </td>
                        </tr>
						<tr>
							<td colspan="6">Jalan Kartini No.26</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td colspan="4"></td>
						</tr>
						<tr>
							<td colspan="6">Telp. (0541) 742756 - 748460 Fax. 731305</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td colspan="4"></td>
						</tr>
						<tr>
							<td colspan="6">S A M A R I N D A</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td colspan="4"></td>
						</tr>
						<tr border="0">
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td colspan="4"></td>
						</tr>
					</table>
					<div style="clear: both;"></div>
					<br>
					<table class="table table-bordered table-hover">
									
                                <thead>
                                	<tr>
										
										<td colspan="5">&nbsp; <span style="float: left;">Tanggal : <?php echo @$r->tanggal ?></span></td>
										<td colspan="10"><span>Kepada Yth : {{ $r->kepada }}</span></td>
									</tr>
									<tr style="height: 10px;">
										<td colspan="15"></td>
									</tr>
                                    <tr>
                                        <th>#</th>
                                     
                                        <th>NO OPB</th>
                                        <th>Kode Barang</th>
                                        <th>Nama Barang</th>
                                       
                                        <th colspan="2">Merek Unit</th>
                                        <th>Supplier</th>
                                        
                                        <th>Keterangan</th>
                                        <th colspan="2">Qty</th>
                                     
                                        <th>Harga</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $no=1;
                                    $jml_total = 0;
                                      $total = 0;
                                      $jumlahItem = 0;
                                      $jumlahPengeluaran = 0; ?>
                                    <?php foreach ($r->detail as $d): ?>
                                        
                                        <?php foreach ($d->pemesanan->bbm as $cc) {
                                                foreach ($cc->detail as $dd) {
                                                    $jumlah_row = $dd->jumlah*$dd->harga;
                                                    ?>
                                                        <tr>
                                                            
                                                            <td>{{ $no }}</td>
                                                            
                                                            <td><?php echo $cc->nomor ?></td>
                                                            <td><?php echo $dd->barang->kode ?></td>
                                                            <td><?php echo $dd->barang->nama ?></td>
                                                            
                                                            <td colspan="2"><?php echo $dd->barang->merek->unit ?> <?php echo $dd->barang->merek->nama ?></td>
                                                            <td>{{ $d->pemesanan->pemasok->nama }} </td>
                                                            

                                                            <td><?php echo $dd->keterangan ?></td>
                                                            <td colspan="2">
                                                                <?php echo $dd->jumlah ?> <?php echo $dd->barang->satuan->nama ?>
                                                            </td>
                                                            
                                                            
                                                            <td>
                                                                Rp.<?php echo number_format($dd->harga) ?>
                                                            </td>
                                                            <td>Rp.{{ number_format($jumlah_row) }}</td>
                                                        </tr>
                                                        <?php $no++ ?>
                                    <?php $jumlahItem += $dd->jumlah; ?>
                                    <?php $jumlahPengeluaran += ($dd->jumlah * $dd->harga); ?>
                                                    <?php

                                                }
                                                
                                           
                                                        
                                            
                                        }  $no++ ?>

                                        
                                    <?php endforeach; ?>
                                </tbody>
                                <tfoot>
                                
                            </tfoot>
                            </table>
						<table width="100%"class="table table-bordered table-hover">
							<tr style="height: 60px;">
									<td colspan="8">
                                        Dikirim Melalui : 
                                        <?php echo $r->dikirim ?> 
                                        <br>
                                        Catatan : 
                                        <?php echo $r->keterangan ?>                           
                                    </td>
									<td colspan="8">
										<center style="position:relative; bottom:-15px;x">
											<i>&nbsp;</i>
											Total : 
											Rp. <?php echo number_format($jumlahPengeluaran,2) ?>
										</center>
									</td>
								</tr>
								<tr>
									
									
									<td colspan="4" center>Mengetahui</td>
									<td colspan="4" center>Pengantar</td>
									<td colspan="4" center>Penerima</td>
									<td colspan="4" center>Pengirim</td>
								</tr>
								<tr style="height: 100px">
									
									<td colspan="4" center>&nbsp;</td>
                                    <td colspan="4" center>&nbsp;</td>
                                    <td colspan="4" center>&nbsp;</td>
                                    <td colspan="4" center>&nbsp;</td>
								</tr>
								<tr>
									<td colspan="4" center>{{ $r->mengetahui_user->nama }}</td>
                                    <td colspan="4" center>{{ $r->pengantar_user->nama }}</td>
                                    <td colspan="4" center>{{ $r->penerima_user->nama }}</td>
                                    <td colspan="4" center>{{ $r->pengirim_user->nama }}</td>
								</tr>
						</table>
                        
                    

                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
