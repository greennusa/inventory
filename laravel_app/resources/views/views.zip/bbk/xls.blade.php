<?php 
	$date = date('d/m/Y');
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=bbk-".$r->nomor."- ".$date.".xls");
	header("Pragma: no-cache");
	header("Expires: 0");
 ?>
<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{$r->nomor."-".$r->tanggal}}</title>

    <!-- Styles -->
    
    <link rel="stylesheet" type="text/css" href="{{ asset('bootstrap/theme/16/bootstrap.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('selectbox/css/bootstrap-select.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('jquery-ui/jquery-ui.min.css') }}">




    <script src="{{ asset('jquery/jquery-1.11.3.min.js') }}"></script>
    <script src="{{ asset('bootstrap/js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('selectbox/js/bootstrap-select.min.js') }}"></script>
    <script src="{{ asset('jquery-ui/jquery-ui.min.js') }}"></script>
    <script src="{{ asset('js/bootstrap-notify.min.js') }}" ></script>

    
    <style>
        .ui-datepicker-calendar {
            display: none;
        }
    </style>
    <style type="text/css">

        #gambar{

            float: right; margin-top: -40%; margin-right: auto;

            max-width: 40%;

            max-height: 30%;

        }

        @media screen and (max-width: 1199px) {

          #gambar {

            float: none;

            margin-top: 5px;

            margin-bottom: 5px;

          }

        }



    </style>



</head>
<body >
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
               

                <div class="panel-body" >
                    <table style="float: right;" width="100%" >
						<tr>
							<td rowspan="4" colspan="2" width="100"><img width="100" src="<?php echo "http://$_SERVER[HTTP_HOST]"; ?>/inventoryudit/assets/images/udit.png" alt="" /></td>
							<td colspan="6"><h2>PT. Utama Damai Indah Timber</h2></td>
							<td>&nbsp;</td>
							<td width="20%">&nbsp;</td>
							<td width="1%">&nbsp;</td>
							<td width="1%">&nbsp;</td>
							<td>Nomor : </td>
							<td colspan="4"><?php echo @$r->nomor //echo @$this->Mitem_out->getPermintaanOne($r->permintaan_id)->nomor ?> </td>
						</tr>
						<tr>
							<td colspan="6">Jalan Kartini No.26</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td colspan="4"></td>
						</tr>
						<tr>
							<td colspan="6">Telp. (0541) 742756 - 748460 Fax. 731305</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td colspan="4"></td>
						</tr>
						<tr>
							<td colspan="6">S A M A R I N D A</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td colspan="4"></td>
						</tr>
						<tr border="0">
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td colspan="4"></td>
						</tr>
					</table>
					<div style="clear: both;"></div>
					<br>
					<table border="1">
									
                                <thead>
                                	<tr>
										<td colspan="5">Surat Pengiriman Barang : (D/N)</td>
										<td colspan="2">&nbsp; <span style="float: right">Tanggal : <?php echo @$r->tanggal ?></span></td>
										<td colspan="8"><span>Kepada Yth : </span></td>
									</tr>
									<tr style="height: 10px;">
										<td colspan="15"></td>
									</tr>
                                    <tr>
                                        <th>#</th>
                                        <th>NO PO</th>
                                        <th>NO OPB</th>
                                        <th>Kode Barang</th>
                                        <th>Nama Barang</th>
                                        <th>Merek</th>
                                        <th>Merek Unit</th>
                                        <th>Supplier</th>
                                        <th>Halaman</th>
                                        <th>Indeks</th>
                                        <th>Keterangan</th>
                                        <th>Jumlah</th>
                                        <th>Satuan</th>
                                        <th>Harga</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $no=1;
                                    $jml_total = 0;
                                      $total = 0;
                                      $jumlahItem = 0;
                                      $jumlahPengeluaran = 0; ?>
                                    <?php foreach ($r->detail as $d): ?>
                                        <tr>
                                            <input type="hidden" name="id[]" value="<?php echo $d->id ?>">
                                            <input type="hidden" name="barang_id[]" value="<?php echo $d->barang_id ?>">
                                            <td><?php echo $no ?></td>
                                            <td><?php echo $d->pemesanan->nomor ?></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                       
                                            <td></td>
                                          
                                            <td>
                                               {{ $d->pemesanan->pemasok->nama }} 
                                            </td>
                                            <td>
                                                
                                            </td>
                                            
                                            <td></td>
                                            <td></td>
                                        </tr>
                                        <?php foreach ($d->pemesanan->bbm as $cc) {
                                                foreach ($cc->detail as $dd) {
                                                    $jumlah_row = $dd->jumlah*$dd->harga;
                                                    ?>
                                                        <tr>
                                                            
                                                            <td></td>
                                                            <td></td>
                                                            <td><?php echo $cc->nomor ?></td>
                                                            <td><?php echo $dd->barang->kode ?></td>
                                                            <td><?php echo $dd->barang->nama ?></td>
                                                            <td><?php echo $dd->barang->merek->nama ?></td>
                                                            <td><?php echo $dd->barang->merek->unit ?></td>
                                                            <td></td>
                                                            <td><?php echo $dd->barang->halaman ?></td>
                                                            <td><?php echo $dd->barang->indeks ?></td>

                                                            <td><?php echo $dd->keterangan ?></td>
                                                            <td>
                                                                <?php echo $dd->jumlah ?>
                                                            </td>
                                                            
                                                            <td><?php echo $dd->barang->satuan->nama ?></td>
                                                            <td>
                                                                Rp.<?php echo number_format($dd->harga) ?>
                                                            </td>
                                                            <td>Rp.{{ number_format($jumlah_row) }}</td>
                                                        </tr>
                                                        <?php $no++ ?>
                                    <?php $jumlahItem += $dd->jumlah; ?>
                                    <?php $jumlahPengeluaran += ($dd->jumlah * $dd->harga); ?>
                                                    <?php

                                                }
                                                
                                           
                                                        
                                            
                                        }  $no++ ?>

                                        
                                    <?php endforeach; ?>
                                </tbody>
                                <tfoot>
                                
                            </tfoot>
                            </table>
						<table width="100%" border="1">
							<tr style="height: 60px;">
									<td colspan="8"><span style=" position:relative; top:-13px;">&nbsp;</span> <span style="float: right;">&nbsp;</span></td>
									<td colspan="8">
										<center style="position:relative; bottom:-15px;x">
											<i>&nbsp;</i>
											Total : 
											Rp. <?php echo number_format($jumlahPengeluaran,2) ?>
										</center>
									</td>
								</tr>
								<tr>
									<td colspan="2">Kode Selisih</td>
									<td>C=Cocok</td>
									<td>S=Salah</td>
									<td>K=Kurang</td>
									<td>L=Lebih</td>
									<td colspan="2">R=Rusak</td>
									<td colspan="2" center>Mengetahui</td>
									<td colspan="2" center>Pengantar</td>
									<td colspan="2" center>Penerima</td>
									<td colspan="2" center>Pengirim</td>
								</tr>
								<tr style="height: 100px">
									<td colspan="6">
										<span style=" position:relative; top:-30px;">&nbsp;</span>
										<br>
										<?php echo $r->keterangan ?>
									</td>
									<td colspan="2">&nbsp;</td>
									<td colspan="2">&nbsp;</td>
									<td colspan="2">&nbsp;</td>
									<td colspan="2">&nbsp;</td>
									<td colspan="2">&nbsp;</td>
								</tr>
								<tr>
									<td colspan="8">&nbsp;</td>
									<td colspan="2"></td>
									<td colspan="2">&nbsp;</td>
									<td colspan="2">&nbsp;</td>
									<td colspan="2">&nbsp;</td>
								</tr>
						</table>
                        
                    

                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
