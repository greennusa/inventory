@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">Detail Barang Di Gudang</div>

                <div class="panel-body">
                    
                	<div class="col-md-4">
						<h2>Detail Barang</h2>
						<table class="table">
							<tr><th>Kode Barang</th><td>:</td><td><?php echo $r->barang->kode ?></td></tr>
							<tr><th>Nama Barang</th><td>:</td><td><?php echo $r->barang->nama ?></td></tr>
							<tr><th>Merek</th><td>:</td><td><?php echo $r->barang->merek->nama ?></td></tr>
							<tr><th>Merek Unit</th><td>:</td><td><?php echo $r->barang->merek->unit ?></td></tr>
							<tr><th>Keterangan</th><td>:</td><td><?php echo $r->barang->keterangan ?></td></tr>
							<tr><th>Stok</th><td>:</td><td><?php echo $r->stok ?></td></tr>
							<tr><th>Harga</th><td>:</td><td>Rp. <?php echo number_format($r->barang->harga) ?></td></tr>
							<tr><th>Satuan</th><td>:</td><td><?php echo $r->barang->satuan->nama ?></td></tr>
						</table>

						<p></p>
						<a class="btn btn-default" onclick=self.history.back()>Kembali</a>
					</div>
					<div class="col-md-4">
						<h2>Serial Barang</h2>
						<table class="table">
							<tr>
								<th>No</th>
								<th>SN</th>
							</tr>
							<?php $no = 1; ?>
							<?php foreach ($r->serial as $item) {
								?>
								<tr>
									<td>{{ $no++ }}</td>
									<td>{{ $item->sn }}</td>
								</tr>
								<?php
							} ?>
							
						</table>

						
					</div>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection

