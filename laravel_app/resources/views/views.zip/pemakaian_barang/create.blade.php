@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">Tambah Pemakaian Barang</div>

                <div class="panel-body">
                    <form class="form-horizontal" action="<?php echo url('item_use') ?>" method="POST">
                        {{ csrf_field() }}
                        <input type="hidden" name="pemesanan_baru" id="pemesanan_baru" value="tidak">
                        
                            <div class="form-group">

                                <label for="nama" class="col-lg-2 control-label" >Nomor Pemakaian</label>

                                <div class="col-lg-6">

                                    <input type="text"  class="form-control" name="nomor"  id="nomor"  placeholder="Nomor Pemakaian" required>

                                </div>

                            </div>

                            <div class="form-group">

                                <label for="nama" class="col-lg-2 control-label" >Tanggal Pemakaian</label>

                                <div class="col-lg-6">

                                    <input type="date" class="form-control datepickers" id="tanggal" name="tanggal" placeholder="Tanggal Pemakaian" required >

                                </div>

                            </div>

                            <div class="form-group">

                                <label for="nama" class="col-lg-2 control-label" >Keterangan Pemakaian</label>

                                <div class="col-lg-6">

                                    <input type="text" class="form-control" id="keterangan" name="keterangan" placeholder="Keterangan Pemakaian" required >

                                </div>

                            </div>

                            <div class="form-group">
                                <label for="permintaan_id" class="col-lg-2 control-label">Operator</label>
                                <div class="col-lg-6">
                                    <select onchange="get_supplier(this.value)" class="form-control selectpicker" name="permintaan_id" id="permintaan_id" data-live-search="true">
                                        <option></option>
                                        <?php foreach ($user as $u): ?>
                                            <option value="<?php echo $u->id ?>" ><?php echo $u->nama ?></option>
                                        <?php endforeach ?>             
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">

                                <label for="merek_id" class="col-lg-2 control-label">Unit</label>

                                <div class="col-lg-6">

                                    <select onchange="get_barang_camp(this.value)" class="form-control selectpicker" name="merek_id" id="merek_id" data-live-search="true" required>
                                        <option></option>
                                        <?php foreach ($merek as $u): ?>

                                        <option value="<?php echo $u->id ?>"><?php echo $u->nama ?></option>
                                    <?php endforeach ?>
                                    </select>

                                </div>

                            </div>

                            <div class="form-group">
                                <label for="barang_id" class="col-lg-2 control-label">Barang Di Camp</label>
                                <div class="col-lg-6" id="barang_id">
                                    
                                </div>
                            </div>

                            

                            
                            
                         

                            

                        

                        <div class="form-group">

                            <div class="col-lg-10 col-lg-offset-2">

                                <input type=button value=Batal class="btn btn-default" onclick=self.history.back()>

                                <button  type="submit" class="btn btn-primary">Simpan</button>

                            </div>

                        </div>
                            
                    </form>


                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    function get_barang_camp(id){
        $('#loading-list-menu').show();
        $.ajax({
            url: '<?php echo url('ajax/get_barang_camp/') ?>/'+id,
            type: 'GET',
            success: function(data) {
                if(data == null || data == '' || data == '<option></option>'){
                    alert('barang dengan unit/merek ini tidak di temukan di camp');
                }
                $('#barang_id').html(data);
                
                $('#loading-list-menu').hide();
            }
           
        }).fail(function() {
            $("#list-barang").html('');
        }).always(function() {
            $('#loading-list-menu').hide();
        });
        
        
    }
</script>
@endsection

