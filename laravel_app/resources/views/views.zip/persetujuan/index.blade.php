@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">Persetujuan</div>

                <div class="panel-body">
                    <form class="form-inline">
                        <div class="form-group">
                            <input type="text" class="form-control" name="q" placeholder="Pencarian" value="">
                        </div>
                        <button type="submit" class="btn btn-default">Cari</button>
                        
                    </form>
                    <p></p>

                    <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nomor Permintaan</th>
                            <th>Tanggal</th>
                            <th>Kantor</th>
                            <th>Unit</th>
                            <th>Jenis</th>
                            <th>E/N No</th>
                            <th>S/N No</th>
                            <th>Diketahui</th>
                           
                            <th>Pemeriksa</th>
                            <th>Setuju</th>
                            <th>Penyetuju</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                         <?php 
                         $page = 0;
                         if(isset($_GET['page']) && $_GET['page'] > 1){
                            $page = $_GET['page']*10;
                         }
                         $no = 1*$page+1; 
                         ?>
                        @foreach ($tables as $t)
                            <tr>
                                <td><?php echo $no ?></td>
                                <td><?php echo $t->nomor ?></td>
                                <td><?php echo $t->tanggal ?></td>
                                <td><?php echo $t->lokasi->nama ?></td>
                                <td><?php echo $t->merek->nama ?></td>
                                <td><?php echo $t->merek->unit ?></td>
                                <td><?php echo $t->merek->no_en ?></td>
                                <td><?php echo $t->merek->no_sn ?></td>
                                <td><?php echo $t->pembuat->nama ?></td>
                                
                                <td><?php echo $t->diperiksa->nama ?></td>
                                <td>
                                    <?php if ($t->setuju == 1): ?>
                                        Tidak
                                    <?php elseif($t->setuju == 2): ?>
                                        Ya
                                    <?php endif ?>
                                </td>
                                <td><?php echo ($t->disetujui_id!=0) ? $t->disetujui->nama : "" ?></td>
                                <td>
                                    
                                    
                                    <a class="btn btn-success" href="<?php echo url('approval/'.$t->id) ?>"><span class="glyphicon glyphicon-search" aria-hidden="true"></span> Detail</a>
                                    
                                </td>
                            </tr>
                            <?php $no++; ?>
                        @endforeach
                    </table>
                    <center>
                        {{$tables->appends(request()->input())->render()}}
                    </center>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
