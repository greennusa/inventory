@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">Persetujuan</div>

                <div class="panel-body">
                    <form class="form-horizontal" method="POST" >
                    	{{ csrf_field() }}
                    	<input type="hidden" name="_method" value="PUT">
						<div class="form-group">
							<label for="nomor" class="col-lg-2 control-label">Nomor Permintaan</label>
							<div class="col-lg-3">
								<input type="text" value="<?php echo @$r->nomor ?>" class="form-control" name="nomor" id="nomor" placeholder="Nomor Permintaan" required disabled>
							</div>
						</div>
						<div class="form-group">
							<label for="tanggal" class="col-lg-2 control-label">Tanggal</label>
							<div class="col-lg-3">
								<input type="text" value="<?php echo @$r->tanggal ?>" class="form-control datepickers" name="tanggal" id="tanggal" placeholder="Tanggal" required disabled>
							</div>
						</div>
						<div class="form-group">
							<label for="lokasi_id" class="col-lg-2 control-label">Kantor</label>
							<div class="col-lg-3">
								<select class="form-control selectpicker" name="lokasi_id" id="lokasi_id" data-live-search="true" disabled>
									<option></option>
									<?php foreach ($lokasi as $j): ?>
										<option value="<?php echo $j->id ?>" <?php if ($j->id == @$r->lokasi_id) {echo "selected";} ?>><?php echo $j->nama ?></option>
									<?php endforeach ?>				
								</select>
							</div>
						</div>
						<div class="form-group">
							<label for="merek_id" class="col-lg-2 control-label">Unit</label>
							<div class="col-lg-3">
								<select class="form-control selectpicker" name="merek_id" id="merek_id" data-live-search="true" disabled>
									<option></option>
									<?php foreach ($merek as $m): ?>
										<option value="<?php echo $m->id ?>" <?php if ($m->id == @$r->merek_id) {echo "selected";} ?>><?php echo $m->kode ?> - <?php echo $m->nama ?></option>
									<?php endforeach ?>				
								</select>
							</div>
						</div>
						<div class="form-group">
							<label for="en_no" class="col-lg-2 control-label">Kode Unit</label>
							<div class="col-lg-3">
								<input type="text" value="<?php echo @$r->kode_unit ?>" class="form-control" name="kode_unit" id="kode_unit" placeholder="Kode Unit" disabled>
							</div>
						</div>
					    <div class="form-group">
							<label for="en_no" class="col-lg-2 control-label">E/N No</label>
							<div class="col-lg-3">
								<input type="text" value="<?php echo @$r->merek->no_en ?>" class="form-control" name="en_no" id="en_no" placeholder="E/N No" disabled>
							</div>
						</div>
						<div class="form-group">
							<label for="sn_no" class="col-lg-2 control-label">S/N No</label>
							<div class="col-lg-3">
								<input type="text" value="<?php echo @$r->merek->no_sn ?>" class="form-control" name="sn_no" id="sn_no" placeholder="Nama S/N No" disabled>
							</div>
						</div>
					        <div class="form-group">
							<label for="sn_no" class="col-lg-2 control-label">Nama Merek</label>
							<div class="col-lg-3">
								<input type="text" disabled value="<?php echo @$r->merek->nama ?>" class="form-control" name="nama_merek" id="sn_no" placeholder="Nama Merek">
							</div>
						</div>
					    <div class="form-group">
							<label for="sn_no" class="col-lg-2 control-label">Merek Unit</label>
							<div class="col-lg-3">
								<input type="text" disabled value="<?php echo @$r->merek->unit ?>" class="form-control" name="merek_unit" id="sn_no" placeholder="Merek Unit">
							</div>
						</div>
						<div class="form-group">
							<label for="sifat" class="col-lg-2 control-label">Sifat</label>
							<div class="col-lg-3">
								<select class="form-control selectpicker" name="sifat" id="sifat" data-live-search="true" disabled>
									<option></option>
									<option value="0" <?php if (@$r->sifat == 0) {echo "selected";} ?>>Biasa</option>
									<option value="1" <?php if (@$r->sifat == 1) {echo "selected";} ?>>Urgent</option>			
								</select>
							</div>
						</div>
						<div class="form-group">
							<label for="diketahui_id" class="col-lg-2 control-label">Diketahui oleh</label>
							<div class="col-lg-3">
								<select class="form-control selectpicker" name="diketahui_id" id="diketahui_id" data-live-search="true" disabled>
									<option></option>
									<?php foreach ($user as $u): ?>
										<option value="<?php echo $u->id ?>" <?php if ($u->id == @$r->diketahui_id) {echo "selected";} ?>><?php echo $u->nama ?></option>
									<?php endforeach ?>				
								</select>
							</div>
						</div>
						
						<div class="form-group">
							<label for="setuju" class="col-lg-2 control-label">Setuju</label>
							<div class="col-lg-3">
								
								<select class="form-control selectpicker" name="setuju" id="setuju" data-live-search="true" required>
									<option></option>
									<option value="1" <?php if (@$r->setuju == 1) {echo "selected";} ?>>Tidak</option>
									<option value="2" <?php if (@$r->setuju == 2) {echo "selected";} ?>>Ya</option>			
								</select>
							</div>
						</div>
						<div class="form-group">
							<div class="col-lg-10 col-lg-offset-2">
									<a class="btn btn-default" href="<?php echo url('approval') ?>">Kembali</a>
									<button type="submit" class="btn btn-success">Selesai</button>
							</div>
						</div>
					</form>
					<form  method="POST" action="{{ url('approval/'.$r->id.'/detail') }}">
						{{ csrf_field() }}
						<table class="table table-bordered table-hover">
							<thead>
								<tr>
									<th>#</th>
									<th>Kode Barang</th>
									<th>Nama Barang</th>
									<th>Halaman</th>
									<th>Indeks</th>
									<th>Pemasok</th>
									<th>Jumlah Permintaan</th>
									<th>Satuan</th>
									<th>Jumlah Disetujui</th>
									<th>Harga Satuan</th>
									<th>Keterangan</th>
									
									<th>Status</th>
									
								</tr>
							</thead>
							<tbody>
								<?php $no=1;
									  $jml_total = 0;
									  $total = 0;
									  $jumlahItem = 0;
									  $jumlahPengeluaran = 0;
								?>
								<?php foreach ($r->detail as $d): ?>
									<tr>
										
											
											<input type="hidden" name="id_detail[]" value="<?php echo $d->id ?>">
					                        <input type="hidden" name="id_barang[]" value="<?php echo $d->barang_id ?>">
											
											<td><?php echo $no ?></td>
											<td><?php echo $d->barang->kode ?></td>
											<td><?php echo $d->barang->nama ?></td>
											<td><?php echo $d->barang->halaman ?></td>
											<td><?php echo $d->barang->indeks ?></td>
											<td><?php if($d->pemasok){ echo $d->pemasok->nama; } else{ echo "Belum Ada Pemasok"; } ?></td>
											<td><?php echo $d->jumlah ?></td>
											<td><?php echo $d->barang->satuan->nama ?></td>
											<td><input class="form-control" type="number" name="jumlah[]" max="<?php echo $d->jumlah ?>" value="<?php echo $d->jumlah_disetujui ?>"></td>
											<td><input class="form-control" type="number" name="harga[]" value="<?php echo $d->harga ?>"></td>
											<td><textarea  name="keterangan[]"><?php echo $d->keterangan ?></textarea></td>
											
											<td>
												<?php if($d->pemasok){ ?>
												<select class="form-control selectpicker" name="status[]" id="status" data-live-search="true" required>
													
													<option value="1" <?php if (@$d->status == 1) {echo "selected";} ?>>Tidak Ada</option>
													<option value="2" <?php if (@$d->status == 2) {echo "selected";} ?>>Ada</option>
													<option value="3" <?php if (@$d->status == 3) {echo "selected";} ?>>Pending</option>			
												</select>
											<?php } else{ echo "Belum Ada Pemasok"; } ?>
													
												
											</td>
										
										
									</tr>
									<?php $no++; ?>
									<?php $jumlahItem += $d->jumlah; ?>
									<?php $jumlahPengeluaran += ($d->jumlah * $d->harga); ?>
								<?php endforeach ?>
							</tbody>
							<tfoot>
								<tr>
									<td colspan="9" align="right"><b>Total : </b></td>
									<td><b><center><?php echo $jumlahItem ?></center></b></td>
									<td colspan="3"><b>Rp. <?=number_format($jumlahPengeluaran)?></b></td>
								</tr>
							</tfoot>
						</table>
							<button type="submit" class="btn btn-success">Ubah</button>
						</form>




                </div>
            </div>
        </div>
    </div>
</div>
@endsection

