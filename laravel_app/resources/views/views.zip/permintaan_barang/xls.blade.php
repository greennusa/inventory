<?php 
	$date = date('d/m/Y');
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=purchase-request-".$r->nomor."- ".$date.".xls");
	header("Pragma: no-cache");
	header("Expires: 0");
 ?>

<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{$r->nomor."-".$r->tanggal}}</title>

    <!-- Styles -->
    
    <link rel="stylesheet" type="text/css" href="{{ asset('bootstrap/theme/16/bootstrap.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('selectbox/css/bootstrap-select.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('jquery-ui/jquery-ui.min.css') }}">




    <script src="{{ asset('jquery/jquery-1.11.3.min.js') }}"></script>
    <script src="{{ asset('bootstrap/js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('selectbox/js/bootstrap-select.min.js') }}"></script>
    <script src="{{ asset('jquery-ui/jquery-ui.min.js') }}"></script>
    <script src="{{ asset('js/bootstrap-notify.min.js') }}" ></script>

    
    <style>
        .ui-datepicker-calendar {
            display: none;
        }
    </style>
    <style type="text/css">
    	body {
    		font-family: "Open Sans", "Helvetica Neue", Helvetica, Arial, sans-serif;
    	}

        #gambar{

            float: right; margin-top: -40%; margin-right: auto;

            max-width: 40%;

            max-height: 30%;

        }

        @media screen and (max-width: 1199px) {

          #gambar {

            float: none;

            margin-top: 5px;

            margin-bottom: 5px;

          }

        }



    </style>



</head>
<body >
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default" style="border: none;">
               
            	
                <div class="panel-body" style="border: none;">
                	
                
                	
                    <table border="0" cellpadding="5" cellspacing="0" width="100%">

						<tr>
							<td width="30%">PT Utama Damai Indah Timber</td>
							<td align="center" ><b>Permintaan Barang</b></td>

						</tr>

						<tr>
							<td width="30%"><img src="{{ url('images/udit.png') }}" width="70"><br><br></td>
							<td align="center" ><b>Nomor : <?php echo @$r->nomor ?></b></td>

						</tr>

						<tr>
							<td width="30%"><u>BC-Sei.Sentiang</u></td>
							<td width="70%"></td><td width="75">Unit Code</td><td width="1">:</td><td><?php echo  $r->merek->kode; ?></td>

						</tr>

						<tr>
							<td width="30%">Jalan Kartini No.26</td>
							<td></td><td>Jenis/Type</td><td>:</td><td><?php echo  $r->merek->unit; ?> <?php echo  $r->merek->nama; ?></td>

						</tr>

						<tr>
							<td width="30%">Telp. (0541) 742756 - 748460 Fax. 731305</td>
							<td></td><td>E/N No</td><td>:</td><td><?php echo @$r->merek->no_en ?></td>

						</tr>

						<tr>
							<td width="30%">Samarinda</td>
							<td></td><td>S/N No</td><td>:</td><td><?php echo @$r->merek->no_sn ?></td>

						</tr>

						<tr>
							<td colspan="2"></td>

							<td>Tanggal</td>
							<td>:</td>
							<td><?php echo @$r->tanggal ?></td>
						</tr>

						</table>

						<br>



						<table border="1" cellpadding="5" cellspacing="0" width="100%">

							<thead style="text-align: center;">

								<tr  align="center" valign="center" style="text-align: center;">

									<th style="text-align: center;" rowspan="2">No</th>

									<th style="text-align: center;" colspan="2" >Spesifikasi Barang</th>

									<th style="text-align: center;">Fig /</th>

									<th style="text-align: center;">Item /</th>

									<th style="text-align: center;">Jumlah</th>
									<th style="text-align: center;">Keterangan</th>

								</tr >

								<tr align="center" style="text-align: center;">

									<th style="text-align: center;">Kode</th>

									<th style="text-align: center;">Nama</th>

									<th style="text-align: center;">Hal</th>

									<th style="text-align: center;">Indek</th>

									<th style="text-align: center;">Dipesan</th>

									<th style="text-align: center;"></th>

								</tr>

								

							</thead>

							<tbody>

								<?php $no=1 ?>

								<?php foreach ($r->detail as $d): ?>

									<tr align="center">

										<form  method="POST">

											<input type="hidden" name="id" value="<?php echo $d->id ?>">

											

											<td><?php echo $no ?></td>

											<td><?php echo $d->barang->kode ?></td>

											<td><?php echo $d->barang->nama ?></td>

											

											<td><?php echo $d->barang->halaman ?></td>

											<td><?php echo $d->barang->indeks ?></td>

											<td><?php echo $d->jumlah ?> <?php echo $d->barang->satuan->nama ?></td>

											<td><?php echo $d->barang->keterangan ?></td>

										</form>

									</tr>

									<?php $no++ ?>

								<?php endforeach ?>

							</tbody>

						</table>

						<br>

						<table border="0" cellpadding="5" cellspacing="0" width="100%">

							


							<tr align="center">

								<td>Dibuat Oleh</td><td>Diperiksa Oleh</td><td>Diketahui Oleh</td><td>Disetujui Oleh</td>

							</tr>

							<tr align="center">

								<td><br><br><br>{{ $r->pembuat->nama }}</td>
								<td><br><br><br>{{ $r->diperiksa->nama }}</td>
								<td><br><br><br>{{ $r->diketahui->nama }}</td>
								<td><br><br><br>{{ $r->disetujui->nama }}</td>


							</tr>

							

						</table>
                    

                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>

		