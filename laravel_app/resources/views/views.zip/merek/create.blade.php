@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">Tambah Merek</div>

                <div class="panel-body">
                    <form class="form-horizontal" method="POST" action="{{ url('brand') }}">
                    	{{ csrf_field() }}
						<div class="form-group">
							<label for="kode" class="col-lg-2 control-label">Kode Unit</label>
							<div class="col-lg-3">
								<input type="text" value="" class="form-control" name="kode" id="kode" placeholder="Kode Unit" required>
							</div>
						</div>
						<div class="form-group">
							<label for="nama" class="col-lg-2 control-label">Nama</label>
							<div class="col-lg-3">
								<input type="text" value="" class="form-control" name="nama" id="nama" placeholder="Nama" required>
							</div>
						</div>
						<div class="form-group">
							<label for="unit" class="col-lg-2 control-label">Unit</label>
							<div class="col-lg-3">
								<input type="text" value="" class="form-control" name="unit" id="unit" placeholder="Unit" required>
							</div>
						</div>
					    <div class="form-group">
							<label for="no_sn" class="col-lg-2 control-label">No. S/N</label>
							<div class="col-lg-3">
								<input type="text" value="" class="form-control" name="no_sn" id="no_sn" placeholder="No. S/N" required>
							</div>
						</div>
						<div class="form-group">
							<label for="no_en" class="col-lg-2 control-label">No. E/N</label>
							<div class="col-lg-3">
								<input type="text" value="" class="form-control" name="no_en" id="no_en" placeholder="No. E/N" required>
							</div>
						</div>
						<div class="form-group">
							<div class="col-lg-10 col-lg-offset-2">
								<input type=button value=Batal class="btn btn-default" onclick=self.history.back()>
								<button type="submit" class="btn btn-primary">Simpan</button>
							</div>
						</div>
					</form>


                </div>
            </div>
        </div>
    </div>
</div>
@endsection

