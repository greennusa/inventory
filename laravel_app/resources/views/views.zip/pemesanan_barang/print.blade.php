
<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{$r->nomor."-".$r->tanggal}}</title>

    <!-- Styles -->
    
    <link rel="stylesheet" type="text/css" href="{{ asset('bootstrap/theme/16/bootstrap.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('selectbox/css/bootstrap-select.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('jquery-ui/jquery-ui.min.css') }}">




    <script src="{{ asset('jquery/jquery-1.11.3.min.js') }}"></script>
    <script src="{{ asset('bootstrap/js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('selectbox/js/bootstrap-select.min.js') }}"></script>
    <script src="{{ asset('jquery-ui/jquery-ui.min.js') }}"></script>
    <script src="{{ asset('js/bootstrap-notify.min.js') }}" ></script>

    
    <style>
        .ui-datepicker-calendar {
            display: none;
        }
    </style>
    <style type="text/css">
       

        .control-label,.table.table-bordered.table-hover {
            font-size: 10px;
        }

        #gambar{

            float: right; margin-top: -40%; margin-right: auto;

            max-width: 40%;

            max-height: 30%;

        }

        @media screen and (max-width: 1199px) {

          #gambar {

            float: none;

            margin-top: 5px;

            margin-bottom: 5px;

          }

        }



    </style>



</head>
<body onload="window.print()">
<div class="container" >
    <div class="row" >
        <div class="col-md-12" >
            <div class="panel panel-default" style="border: none;">
                

                <div class="panel-body"  style="border: none;">
                    

                    <div class="form-horizontal" style="float: left;width: 50%;text-align: left;">
                        
                        
                        
                        <div class="form-group">

                          
                            <label class="col-lg-6 control-label" style="text-align: left;">
                                PT Utama Damai Indah Timber
                            </label>

                        </div>

                        <div class="form-group">

                          
                            <label class="col-lg-6 control-label" style="text-align: left;">
                                <img src="{{ url('images/udit.png') }}" width="100">
                            </label>

                        </div>

                        <div class="form-group">

                          
                            <label class="col-lg-6 control-label" style="text-align: left;">
                                Jalan Kartini No.26
                            </label>

                        </div>

                        <div class="form-group">

                          
                            <label class="col-lg-6 control-label" style="text-align: left;">
                                Telp. (0541) 742756 - 748460 Fax. 731305
                            </label>

                        </div>

                        <div class="form-group">

                          
                            <label class="col-lg-6 control-label" style="text-align: left;">
                                Samarinda
                            </label>

                        </div>
                            
                    </div>
                    <div class="form-horizontal" style="float: right;width: 50%; text-align: justify;">
                        <div class="form-group">

                            <label for="nama" class="col-lg-10 control-label">Purchase Order</label>

                        

                        </div>
                        
                        <div class="form-group">

                            <label for="nama" class="col-lg-10 control-label">Nomor Pemesanan : {{ $r->nomor }}</label>

                        

                        </div>

                        <div class="form-group">

                            <label for="nama" class="col-lg-10 control-label">Tanggal Pemesanan : {{ $r->tanggal }}</label>

                          

                        </div>

                     

                        <div class="form-group">
                            <label for="supplier_id" class="col-lg-10 control-label">Supplier Barang : {{ $r->pemasok->nama }}</label>
                          
                        </div>

                        <div class="form-group">
                            <label for="supplier_id" class="col-lg-10 control-label">Dikirim Ke : {{ $r->dikirim }}</label>
                            
                        </div>

                      
                            
                    </div>
                    <p></p>
                    <p></p>
                    
                    
                        
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                   
                                    <th>#</th>
                                   
                                    <th>Nama Barang</th>
                                    <th>Kode Barang</th>
                                   
                                    
                                   
                                    <th >Qty</th>
                                    
                                    <th >Harga Satuan</th>
                                    <th>Total</th>
                                    
                                   
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no=1;
                                $jml_total = 0;
                                      $total = 0;
                                      $jumlahItem = 0;
                                      $jumlahPengeluaran = 0;
                                      $opb = 0;
                                 ?>

                                <?php foreach ($r->detail as $d): ?>
                                    <?php $total_row = $d->jumlah*$d->harga; ?>
                                    <?php if($opb != $d->permintaan->id) { ?>
                                    <tr>
                                        <td colspan="8">Keperluan : <?php echo $d->permintaan->keperluan ?> - {{ $d->permintaan->nomor }} - <?php echo $d->barang->merek->nama ?> - <?php echo $d->barang->merek->unit ?></td>
                                    </tr>
                                    <?php $opb = $d->permintaan->id; } ?>
                                    <tr>
                                        
                                            
                                           
                                           
                                            <td><?php echo $no ?></td>
                                           
                                            <td><?php echo $d->nama_barang ?></td>
                                            <td><?php echo $d->barang->kode ?></td>
                                            
                                     
                                            
                                            <td>
                                               <?php echo $d->jumlah ?> <?php echo $d->barang->satuan->nama ?>
                                                
                                                
                                            </td>
                                      
                                            <td>
                                                Rp. <?=number_format($d->harga) ?>
                                            </td>
                                            <td>Rp. <?=number_format($total_row) ?></td>
                                            
                                            
                                        
                                    </tr>
                                    <?php $no++ ?>
                                    <?php $jumlahItem += $d->jumlah; ?>
                                    <?php $jumlahPengeluaran += ($d->jumlah * $d->harga); ?>
                                <?php endforeach ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="4" align="right"><b>Total : </b></td>
                                    <td><b><center><?php echo $jumlahItem ?></center></b></td>
                                    <td colspan="4"><b>Rp. <?=number_format($jumlahPengeluaran)?></b></td>
                                </tr>
                            </tfoot>
                        </table>
                        <table  border="0" cellpadding="5" cellspacing="0" width="100%" >
                            <tr>
                                <td colspan="8">Keterangan : <br> {{ $r->keterangan }} <br><br></td>
                            </tr>
                            <tr style="border: none;margin-top: 50px;">
                                <td colspan="4">Yang Menyetujui</td>
                                <td colspan="4">Yang Mengetahui</td>
                                <td colspan="4">Yang Memesan</td>
                            </tr>
                            
                            <tr style="border: none;">
                                <td colspan="4"><br><br><br>{{ $r->menyetujui_user->nama }}</td>
                                <td colspan="4"><br><br><br>{{ $r->mengetahui_user->nama }}</td>
                                <td colspan="4"><br><br><br>{{ $r->memesan_user->nama }}</td>
                            </tr>
                        </table>
                        
                    

                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>