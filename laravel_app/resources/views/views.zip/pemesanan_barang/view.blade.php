@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">Pemesanan Barang</div>

                <div class="panel-body" >
                    <div class="form-horizontal" >
                        
                        <div class="form-group">

                            <label for="nama" class="col-lg-2 control-label">Nomor Pemesanan</label>

                            <div class="col-lg-3">

                                <input disabled type="text"  class="form-control" name="nomor"  placeholder="Nomor Pemesanan" required value="{{ $r->nomor }}">

                            </div>

                        </div>

                        <div class="form-group">

                            <label for="nama" class="col-lg-2 control-label">Tanggal Pemesanan</label>

                            <div class="col-lg-3">

                                <input disabled  type="date" class="form-control datepickers" name="tanggal" placeholder="Tanggal Pemesanan" required value="{{ $r->tanggal }}">

                            </div>

                        </div>


                        <div class="form-group">
                            <label for="supplier_id" class="col-lg-2 control-label">Supplier Barang</label>
                            <div class="col-lg-3">
                                <input disabled type="text"  class="form-control" name="nomor"  placeholder="Nomor Pemesanan" required value="{{ $r->pemasok->nama }}">
                            </div>
                        </div>

                        <div class="form-group">

                            <label for="nama" class="col-lg-2 control-label">Dikirm Ke</label>

                            <div class="col-lg-3">

                                <input disabled type="text"  class="form-control" name="nomor"  placeholder="Nomor Pemesanan" required value="{{ $r->dikirim }}">

                            </div>

                        </div>

                        <div class="form-group">

                            <label for="nama" class="col-lg-2 control-label"></label>

                            <div class="col-lg-3">

                                <a class="btn btn-success" href="<?php echo url('order') ?>">Selesai</a>

                            </div>

                        </div>

                        
                            
                    </div>
                    <p></p>
                    <p></p>
                    <p>Detail Pemesanan</p>
                    <form action="{{ url('detail_order/0') }}"  method="post">
                        {{ csrf_field() }}
                        <input type="hidden" name="_method" value="PUT">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                   
                                    <th>#</th>
                                    <th>Nomor Permintaan</th>
                                    <th>Kode Barang</th>
                                    <th>Nama Barang</th>
                                    <th>Merek</th>
                                    <th>Merek Unit</th>
                                    <th>Halaman</th>
                                    <th>Indeks</th>
                                    <th >Jumlah</th>
                                    <th >Harga Satuan</th>
                                    
                                    <th>Keterangan</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no=1 ?>
                                <?php foreach ($r->detail as $d): ?>
                                    <tr>    
                                            <input class="form-control" type="hidden" name="detail_id[]" value="<?php echo $d->id ?>">
                                            <td><?php echo $no ?></td>
                                            <td><?php echo $d->permintaan->nomor; ?></td>
                                            <td><?php echo $d->barang->kode ?></td>
                                            <td><input class="form-control" type="text" name="nama_barang[]" value="{{ $d->nama_barang }}"></td>
                                            <td><?php echo $d->barang->merek->nama ?></td>
                                            <td><?php echo $d->barang->merek->unit ?></td>
                                            <td><?php echo $d->barang->halaman ?></td>
                                            <td><?php echo $d->barang->indeks ?></td>
                                            <td>
                                                <?php echo $d->jumlah ?> <?php echo $d->barang->satuan->nama ?>
                                                
                                                
                                            </td>
                                            <td>
                                                Rp.<?php echo number_format($d->harga) ?>
                                            </td>
                                            
                                            <td><?php echo $d->keterangan ?></td>
                                            <td>
                                                
                                                <a class="btn btn-danger" onclick="event.preventDefault();
                                                         document.getElementById('delete<?php echo $d->id;  ?>').submit();return confirm('Apakah anda yakin akan menghapus data ini?');"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span> Hapus</a>
                                                
                                            </td>
                                        
                                    </tr>
                                    <?php $no++ ?>
                                <?php endforeach ?>
                            </tbody>
                        </table>
                        <button name="submit" class="btn btn-primary">Ubah</button>
                    </form>
                        
                            
                        
                        <?php foreach ($r->detail as $d): ?>
                            <form action="{{ url('detail_order/'.$d->id) }}" id="delete<?php echo $d->id;  ?>" method="POST">
                                {{ csrf_field() }}
                                <input type="hidden" name="_method" value="DELETE">
                            </form>
                        <?php endforeach ?>
                    

                </div>
            </div>
        </div>
    </div>
</div>
@endsection

                    